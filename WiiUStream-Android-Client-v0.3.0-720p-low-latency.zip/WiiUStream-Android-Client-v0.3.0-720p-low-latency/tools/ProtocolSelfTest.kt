package com.wiiustream.client.network

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32

private fun packet(
    frameId: Long,
    jpeg: ByteArray,
    index: Int,
    payload: ByteArray,
    crcOverride: Long? = null,
    stream: Int = 1,
    width: Int = 1280,
    height: Int = 720
): ByteArray {
    val count = (jpeg.size + StreamProtocol.VIDEO_PAYLOAD_SIZE - 1) /
        StreamProtocol.VIDEO_PAYLOAD_SIZE
    val crc = crcOverride ?: CRC32().apply { update(jpeg) }.value
    return ByteBuffer.allocate(StreamProtocol.VIDEO_HEADER_SIZE + payload.size)
        .order(ByteOrder.BIG_ENDIAN)
        .putInt(StreamProtocol.VIDEO_MAGIC)
        .put(StreamProtocol.VERSION.toByte())
        .put(stream.toByte())
        .put(0)
        .put(StreamProtocol.VIDEO_HEADER_SIZE.toByte())
        .putInt(frameId.toInt())
        .putInt(jpeg.size)
        .putInt(crc.toInt())
        .putShort(index.toShort())
        .putShort(count.toShort())
        .putShort(payload.size.toShort())
        .putShort(width.toShort())
        .putShort(height.toShort())
        .put(48.toByte())
        .put(0)
        .put(payload)
        .array()
}

private fun chunks(jpeg: ByteArray): List<ByteArray> =
    jpeg.toList().chunked(StreamProtocol.VIDEO_PAYLOAD_SIZE).map { it.toByteArray() }

fun main() {
    check(StreamProtocol.isValidIpv4("192.168.1.42"))
    check(!StreamProtocol.isValidIpv4("999.1.1.1"))
    check(StreamProtocol.isNewerFrame(1, 0))
    check(StreamProtocol.isNewerFrame(0, 0xFFFF_FFFFL))

    val jpeg720p = ByteArray(173_219) { ((it * 31 + 7) and 0xFF).toByte() }
    val parts = chunks(jpeg720p)
    val assembler = FrameAssembler()
    var completed: EncodedFrame? = null

    val order = parts.indices.toMutableList().apply {
        reverse()
        if (size > 4) {
            val first = removeAt(0)
            add(size / 2, first)
        }
    }
    for (index in order) {
        val datagram = packet(100, jpeg720p, index, parts[index])
        val header = StreamProtocol.parseVideoHeader(datagram, datagram.size)
            ?: error("Header rejected")
        assembler.accept(header, datagram)?.let { completed = it }
    }
    check(completed?.jpeg?.contentEquals(jpeg720p) == true)
    check(CRC32().apply { update(completed!!.jpeg) }.value == completed!!.expectedCrc32)

    // Starting frame 102 must immediately make frame 101 stale.
    val older = ByteArray(5_000) { it.toByte() }
    val olderParts = chunks(older)
    val firstOldPacket = packet(101, older, 0, olderParts[0])
    val firstOldHeader = StreamProtocol.parseVideoHeader(firstOldPacket, firstOldPacket.size)!!
    check(assembler.accept(firstOldHeader, firstOldPacket) == null)

    val newer = ByteArray(4_100) { (it * 3).toByte() }
    val newerParts = chunks(newer)
    for (index in newerParts.indices) {
        val datagram = packet(102, newer, index, newerParts[index])
        val header = StreamProtocol.parseVideoHeader(datagram, datagram.size)!!
        assembler.accept(header, datagram)?.let { completed = it }
    }
    check(completed?.frameId == 102L)
    check(assembler.staleFrames >= 1L)

    println("720p protocol self-test passed")
}
