# WiiUStream UDP protocol v1 — profil 720p

Cette application est prévue pour `StreamingPluginWiiU-Aroma-v0.3.0-720p-experimental`.

- contrôle : UDP `9444` ;
- vidéo : UDP `9445` ;
- en-tête vidéo : 32 octets, ordre réseau ;
- charge utile vidéo : 1400 octets maximum ;
- image : JPEG 4:2:0 ;
- CRC32 IEEE sur le JPEG complet ;
- résolution TV prise en charge : jusqu’à 1280 × 720.

Le client ne conserve qu’une seule trame incomplète par flux et abandonne immédiatement une ancienne trame lorsqu’un `frameId` plus récent commence. Une seule image JPEG complète attend le décodage. Ce choix privilégie la latence à la continuité parfaite.
