package com.wiiustream.client.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.view.SurfaceHolder
import android.view.SurfaceView

/**
 * Surface-backed renderer. Frames are drawn directly from the decoder thread,
 * so the Android main thread never becomes a video-frame queue.
 */
internal class StreamView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    @Volatile private var surfaceReady = false

    init {
        holder.addCallback(this)
        setBackgroundColor(Color.BLACK)
    }

    fun renderFrame(bitmap: Bitmap): Boolean {
        if (!surfaceReady || !holder.surface.isValid || bitmap.isRecycled) return false

        var canvas: Canvas? = null
        return try {
            canvas = if (Build.VERSION.SDK_INT >= 26) {
                holder.lockHardwareCanvas()
            } else {
                holder.lockCanvas()
            }
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bitmap, null, destination(bitmap, canvas.width, canvas.height), paint)
            true
        } catch (_: RuntimeException) {
            false
        } finally {
            if (canvas != null) {
                try {
                    holder.unlockCanvasAndPost(canvas)
                } catch (_: RuntimeException) {
                    // Surface may disappear during an orientation change.
                }
            }
        }
    }

    fun clearFrame() {
        if (!surfaceReady || !holder.surface.isValid) return
        var canvas: Canvas? = null
        try {
            canvas = holder.lockCanvas()
            canvas.drawColor(Color.BLACK)
        } catch (_: RuntimeException) {
            // Surface may be transitioning.
        } finally {
            if (canvas != null) {
                try {
                    holder.unlockCanvasAndPost(canvas)
                } catch (_: RuntimeException) {
                    // Ignore a surface destroyed between lock and post.
                }
            }
        }
    }

    private fun destination(bitmap: Bitmap, viewWidth: Int, viewHeight: Int): RectF {
        if (viewWidth <= 0 || viewHeight <= 0) return RectF()
        val sourceRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        val viewRatio = viewWidth.toFloat() / viewHeight.toFloat()
        return if (sourceRatio > viewRatio) {
            val scaledHeight = viewWidth / sourceRatio
            val top = (viewHeight - scaledHeight) / 2f
            RectF(0f, top, viewWidth.toFloat(), top + scaledHeight)
        } else {
            val scaledWidth = viewHeight * sourceRatio
            val left = (viewWidth - scaledWidth) / 2f
            RectF(left, 0f, left + scaledWidth, viewHeight.toFloat())
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceReady = true
        clearFrame()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        surfaceReady = true
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
    }
}
