# Wii U Stream — Android 720p Low Latency

Client Android optimisé pour le plugin Aroma expérimental WiiUStream v0.3.0.

## Optimisations

- réception UDP et décodage JPEG sur des threads séparés ;
- une seule image compressée en attente ;
- abandon d’une image décodée lorsqu’une image plus récente est déjà arrivée ;
- tampon UDP limité à 256 Kio pour éviter plusieurs secondes de file d’attente ;
- assemblage direct des fragments dans le buffer JPEG final ;
- délai maximal de 250 ms pour une image incomplète ;
- rendu direct dans un `SurfaceView` avec canvas matériel ;
- aucune image vidéo placée dans la file du thread principal Android ;
- verrou Wi-Fi faible latence sur Android 10 et versions ultérieures ;
- affichage séparé des FPS reçus et réellement affichés.

## Utilisation

1. Installer le plugin `WiiUStream.wps` v0.3.0 sur la Wii U.
2. Sélectionner le flux **TV**, la résolution **1280 × 720**, la qualité adaptative et 15 FPS.
3. Mettre le téléphone et la Wii U sur le même réseau Wi-Fi.
4. Installer l’APK, saisir l’adresse IPv4 de la Wii U puis toucher **Connexion**.
5. Toucher l’image pour masquer ou réafficher les contrôles.

Réglage initial recommandé : 720p, qualité maximale 45–50, 15 FPS. Augmenter ensuite progressivement à 20 FPS.

## Construction

Le projet utilise Android 8 minimum, JDK 17, Android Gradle Plugin 9.2.1 et `compileSdk 36`.
Le workflow `build-android-720p-from-zip.yml` produit un APK debug installable.

## Limites

- vidéo uniquement, sans audio ;
- UDP sans retransmission ;
- le débit et les FPS maximum restent limités par l’encodage JPEG logiciel de la Wii U ;
- le profil 1400 octets cible le plugin v0.3.0 et n’est pas prévu pour l’ancien plugin à fragments de 1200 octets.
