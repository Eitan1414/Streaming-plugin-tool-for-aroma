# Tests conseillés

1. Commencer en TV 720p, qualité 45, 15 FPS.
2. Vérifier que « affiché » reste proche de « reçu ».
3. Si « retard évité » augmente rapidement mais l’image reste instantanée, le mécanisme faible latence fonctionne.
4. Si les pertes augmentent fortement, baisser la qualité ou rapprocher les appareils du point d’accès.
5. Tester ensuite 20 FPS. Le 720p/30 FPS n’est pas garanti par la Wii U.
