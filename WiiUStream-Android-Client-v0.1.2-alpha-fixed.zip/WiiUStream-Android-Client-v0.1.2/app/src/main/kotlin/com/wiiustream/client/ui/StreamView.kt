package com.wiiustream.client.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

internal class StreamView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var frame: Bitmap? = null

    init {
        setBackgroundColor(Color.BLACK)
    }

    fun setFrame(bitmap: Bitmap) {
        check(isAttachedToWindow || parent != null) { "StreamView must be attached before displaying frames" }
        val previous = frame
        frame = bitmap
        invalidate()
        if (previous !== bitmap && previous?.isRecycled == false) {
            previous.recycle()
        }
    }

    fun clearFrame() {
        val previous = frame
        frame = null
        invalidate()
        if (previous?.isRecycled == false) previous.recycle()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bitmap = frame ?: return
        if (bitmap.isRecycled || width <= 0 || height <= 0) return

        val sourceRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        val viewRatio = width.toFloat() / height.toFloat()
        val destination = if (sourceRatio > viewRatio) {
            val scaledHeight = width / sourceRatio
            val top = (height - scaledHeight) / 2f
            RectF(0f, top, width.toFloat(), top + scaledHeight)
        } else {
            val scaledWidth = height * sourceRatio
            val left = (width - scaledWidth) / 2f
            RectF(left, 0f, left + scaledWidth, height.toFloat())
        }
        canvas.drawBitmap(bitmap, null, destination, paint)
    }

    override fun onDetachedFromWindow() {
        clearFrame()
        super.onDetachedFromWindow()
    }
}
