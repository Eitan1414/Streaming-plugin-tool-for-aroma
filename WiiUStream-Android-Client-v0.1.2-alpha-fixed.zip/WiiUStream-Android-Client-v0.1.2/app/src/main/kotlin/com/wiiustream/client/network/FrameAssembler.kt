package com.wiiustream.client.network

import java.io.ByteArrayOutputStream
import java.util.zip.CRC32

internal class FrameAssembler {
    private val pending = HashMap<Long, PendingFrame>()

    var timedOutFrames: Long = 0
        private set
    var invalidFrames: Long = 0
        private set

    fun accept(header: VideoHeader, packet: ByteArray): CompletedFrame? {
        cleanupExpired(System.nanoTime())

        var frame = pending[header.frameId]
        if (frame == null) {
            frame = PendingFrame(header)
            pending[header.frameId] = frame
        } else if (!frame.matches(header)) {
            pending.remove(header.frameId)
            invalidFrames++
            return null
        }

        if (frame.chunks[header.chunkIndex] == null) {
            val payload = packet.copyOfRange(
                StreamProtocol.VIDEO_HEADER_SIZE,
                StreamProtocol.VIDEO_HEADER_SIZE + header.payloadSize
            )
            frame.chunks[header.chunkIndex] = payload
            frame.receivedChunks++
            frame.receivedBytes += payload.size
        }

        if (frame.receivedChunks != frame.header.chunkCount) return null
        pending.remove(header.frameId)

        if (frame.receivedBytes != frame.header.frameSize) {
            invalidFrames++
            return null
        }

        val output = ByteArrayOutputStream(frame.header.frameSize)
        for (chunk in frame.chunks) {
            if (chunk == null) {
                invalidFrames++
                return null
            }
            output.write(chunk)
        }
        val jpeg = output.toByteArray()
        if (jpeg.size != frame.header.frameSize) {
            invalidFrames++
            return null
        }

        val crc = CRC32().apply { update(jpeg) }.value
        if (crc != frame.header.frameCrc32) {
            invalidFrames++
            return null
        }

        return CompletedFrame(
            jpeg = jpeg,
            stream = frame.header.stream,
            frameId = frame.header.frameId,
            width = frame.header.width,
            height = frame.header.height,
            jpegQuality = frame.header.jpegQuality
        )
    }

    private fun cleanupExpired(nowNs: Long) {
        val iterator = pending.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (nowNs - entry.value.createdAtNs > StreamProtocol.FRAME_TIMEOUT_NS) {
                iterator.remove()
                timedOutFrames++
            }
        }
    }

    private class PendingFrame(val header: VideoHeader) {
        val createdAtNs: Long = System.nanoTime()
        val chunks: Array<ByteArray?> = arrayOfNulls(header.chunkCount)
        var receivedChunks: Int = 0
        var receivedBytes: Int = 0

        fun matches(other: VideoHeader): Boolean =
            header.frameSize == other.frameSize &&
                header.frameCrc32 == other.frameCrc32 &&
                header.chunkCount == other.chunkCount &&
                header.stream == other.stream &&
                header.width == other.width &&
                header.height == other.height &&
                header.jpegQuality == other.jpegQuality
    }
}

internal data class CompletedFrame(
    val jpeg: ByteArray,
    val stream: Int,
    val frameId: Long,
    val width: Int,
    val height: Int,
    val jpegQuality: Int
)
