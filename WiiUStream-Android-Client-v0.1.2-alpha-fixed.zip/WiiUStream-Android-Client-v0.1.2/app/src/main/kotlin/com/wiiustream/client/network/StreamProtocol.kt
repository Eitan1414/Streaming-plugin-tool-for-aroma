package com.wiiustream.client.network

import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

internal object StreamProtocol {
    const val CONTROL_MAGIC: Int = 0x57555343 // WUSC
    const val VIDEO_MAGIC: Int = 0x57555356 // WUSV
    const val VERSION: Int = 1
    const val HELLO_TYPE: Int = 1
    const val CONTROL_PORT: Int = 9444
    const val DEFAULT_VIDEO_PORT: Int = 9445
    const val CONTROL_PACKET_SIZE: Int = 12
    const val VIDEO_HEADER_SIZE: Int = 32
    const val MAX_DATAGRAM_SIZE: Int = 2048
    const val MAX_FRAME_SIZE: Int = 4 * 1024 * 1024
    const val MAX_CHUNK_COUNT: Int = 4096
    const val FRAME_TIMEOUT_NS: Long = 1_000_000_000L

    fun helloPacket(videoPort: Int): ByteArray =
        ByteBuffer.allocate(CONTROL_PACKET_SIZE)
            .order(ByteOrder.BIG_ENDIAN)
            .putInt(CONTROL_MAGIC)
            .put(VERSION.toByte())
            .put(HELLO_TYPE.toByte())
            .putShort(videoPort.toShort())
            .putInt(0)
            .array()

    fun parseVideoHeader(data: ByteArray, packetLength: Int): VideoHeader? {
        if (packetLength < VIDEO_HEADER_SIZE) return null

        val buffer = ByteBuffer.wrap(data, 0, packetLength).order(ByteOrder.BIG_ENDIAN)
        val magic = buffer.int
        val version = buffer.get().toInt() and 0xFF
        val stream = buffer.get().toInt() and 0xFF
        val flags = buffer.get().toInt() and 0xFF
        val headerSize = buffer.get().toInt() and 0xFF
        val frameId = buffer.int.toLong() and 0xFFFF_FFFFL
        val frameSize = buffer.int
        val frameCrc32 = buffer.int.toLong() and 0xFFFF_FFFFL
        val chunkIndex = buffer.short.toInt() and 0xFFFF
        val chunkCount = buffer.short.toInt() and 0xFFFF
        val payloadSize = buffer.short.toInt() and 0xFFFF
        val width = buffer.short.toInt() and 0xFFFF
        val height = buffer.short.toInt() and 0xFFFF
        val jpegQuality = buffer.get().toInt() and 0xFF
        buffer.get() // reserved

        if (magic != VIDEO_MAGIC || version != VERSION || headerSize != VIDEO_HEADER_SIZE) return null
        if (stream !in 0..1 || flags != 0) return null
        if (frameSize !in 1..MAX_FRAME_SIZE) return null
        if (chunkCount !in 1..MAX_CHUNK_COUNT || chunkIndex >= chunkCount) return null
        if (payloadSize <= 0 || payloadSize > packetLength - VIDEO_HEADER_SIZE) return null
        if (width <= 0 || height <= 0 || jpegQuality !in 1..100) return null

        return VideoHeader(
            stream = stream,
            frameId = frameId,
            frameSize = frameSize,
            frameCrc32 = frameCrc32,
            chunkIndex = chunkIndex,
            chunkCount = chunkCount,
            payloadSize = payloadSize,
            width = width,
            height = height,
            jpegQuality = jpegQuality
        )
    }

    fun isValidIpv4(value: String): Boolean {
        val parts = value.trim().split('.')
        if (parts.size != 4) return false
        return parts.all { part ->
            part.isNotEmpty() && part.length <= 3 && part.all(Char::isDigit) &&
                part.toIntOrNull() in 0..255
        }
    }

    fun resolveIpv4(value: String): InetAddress = InetAddress.getByName(value.trim())
}

internal data class VideoHeader(
    val stream: Int,
    val frameId: Long,
    val frameSize: Int,
    val frameCrc32: Long,
    val chunkIndex: Int,
    val chunkCount: Int,
    val payloadSize: Int,
    val width: Int,
    val height: Int,
    val jpegQuality: Int
)
