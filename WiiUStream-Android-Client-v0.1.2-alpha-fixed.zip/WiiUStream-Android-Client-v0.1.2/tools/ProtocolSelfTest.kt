package com.wiiustream.client.network

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32

private fun packet(
    frameId: Long,
    jpeg: ByteArray,
    index: Int,
    count: Int,
    payload: ByteArray,
    crcOverride: Long? = null
): ByteArray {
    val crc = crcOverride ?: CRC32().apply { update(jpeg) }.value
    return ByteBuffer.allocate(StreamProtocol.VIDEO_HEADER_SIZE + payload.size)
        .order(ByteOrder.BIG_ENDIAN)
        .putInt(StreamProtocol.VIDEO_MAGIC)
        .put(StreamProtocol.VERSION.toByte())
        .put(0)
        .put(0)
        .put(StreamProtocol.VIDEO_HEADER_SIZE.toByte())
        .putInt(frameId.toInt())
        .putInt(jpeg.size)
        .putInt(crc.toInt())
        .putShort(index.toShort())
        .putShort(count.toShort())
        .putShort(payload.size.toShort())
        .putShort(640.toShort())
        .putShort(360.toShort())
        .put(60.toByte())
        .put(0)
        .put(payload)
        .array()
}

fun main() {
    check(StreamProtocol.isValidIpv4("192.168.1.42"))
    check(!StreamProtocol.isValidIpv4("999.1.1.1"))

    val jpeg = ByteArray(2_777) { ((it * 31) and 0xFF).toByte() }
    val parts = jpeg.toList().chunked(1_000).map { it.toByteArray() }
    val assembler = FrameAssembler()

    var completed: CompletedFrame? = null
    for (index in listOf(2, 0, 1)) {
        val datagram = packet(7, jpeg, index, parts.size, parts[index])
        val header = StreamProtocol.parseVideoHeader(datagram, datagram.size)
            ?: error("Header rejected")
        assembler.accept(header, datagram)?.let { completed = it }
    }
    check(completed?.jpeg?.contentEquals(jpeg) == true)

    val invalidAssembler = FrameAssembler()
    val bad = packet(8, jpeg, 0, 1, jpeg, crcOverride = 123)
    val badHeader = StreamProtocol.parseVideoHeader(bad, bad.size) ?: error("Bad header rejected too early")
    check(invalidAssembler.accept(badHeader, bad) == null)
    check(invalidAssembler.invalidFrames == 1L)

    println("Protocol self-test passed")
}
