# Wii U Stream protocol v1

The plugin and the client use UDP on the local network.

## Discovery / heartbeat

The client sends a 12-byte packet every second to Wii U UDP port **9444**.
All integer fields use network byte order (big endian).

| Field | Type | Value |
|---|---:|---|
| magic | u32 | `0x57555343` (`WUSC`) |
| version | u8 | `1` |
| type | u8 | `1` (HELLO) |
| video port | u16 | UDP port opened by the client, normally `9445` |
| flags | u32 | reserved, zero |

The plugin considers the client disconnected after five seconds without a HELLO.

## Video packets

A JPEG frame is divided into payloads of at most 1,200 bytes. Every datagram starts
with a 32-byte header:

| Field | Type | Notes |
|---|---:|---|
| magic | u32 | `0x57555356` (`WUSV`) |
| version | u8 | `1` |
| stream | u8 | `0` GamePad, `1` TV |
| flags | u8 | reserved |
| header size | u8 | `32` |
| frame id | u32 | increments for every JPEG |
| frame size | u32 | complete JPEG size |
| frame CRC32 | u32 | CRC32 of the complete JPEG |
| chunk index | u16 | starts at zero |
| chunk count | u16 | number of chunks in the frame |
| payload size | u16 | bytes following the header |
| width | u16 | image width |
| height | u16 | image height |
| JPEG quality | u8 | 20–90 |
| reserved | u8 | zero |

A client should discard incomplete frames after roughly one second. There is no
retransmission in protocol v1: dropping an old frame gives lower latency than
waiting for it while a game is running.
