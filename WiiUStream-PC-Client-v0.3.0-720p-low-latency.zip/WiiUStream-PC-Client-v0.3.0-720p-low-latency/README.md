# WiiUStream PC Client v0.3.0 — 720p Low Latency

Client Windows compatible avec le plugin Aroma Wii U Stream v0.3.0 expérimental.

## Optimisations

- réception UDP et décodage JPEG sur deux threads séparés ;
- une seule image compressée et une seule image décodée peuvent attendre ;
- toute image plus ancienne est supprimée dès qu'une nouvelle commence ;
- délai d'abandon d'une image incomplète réduit à 250 ms ;
- fenêtre réseau limitée pour éviter plusieurs secondes de file ;
- décodage RGB sans conversion supplémentaire quand le JPEG est déjà en RGB ;
- interface interrogée toutes les 8 ms, statistiques limitées à quatre mises à jour par seconde ;
- aucun redimensionnement si l'image 1280×720 correspond déjà à la zone d'affichage ;
- plein écran : `F11`, `Alt+Entrée` ou double-clic ; sortie : `Échap`.

## Utilisation

1. Lancer le plugin sur la Wii U.
2. Mettre le PC et la console sur le même réseau local.
3. Lancer `WiiUStream-PC.exe`.
4. Entrer l'adresse IPv4 de la Wii U puis cliquer sur **Connexion**.

## Réglage 720p conseillé sur la Wii U

```text
Source : TV
Résolution : 1280 x 720
Qualité adaptative : activée
Plafond JPEG : 50
FPS : 15
```

Monter ensuite progressivement à 20 FPS ou à une qualité de 55 si le compteur reste stable.

## Réseau

- présence : UDP 9444 ;
- vidéo : UDP 9445 ;
- autoriser l'application dans le pare-feu Windows sur le réseau privé.
