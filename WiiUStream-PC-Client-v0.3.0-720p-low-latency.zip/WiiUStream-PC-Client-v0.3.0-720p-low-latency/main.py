from __future__ import annotations

import argparse
import tkinter as tk

from wiiu_stream.app import WiiUStreamApp


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Client PC pour WiiUStream Aroma")
    parser.add_argument("--ip", default="", help="Adresse IPv4 de la Wii U")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = tk.Tk()
    WiiUStreamApp(root, initial_ip=args.ip)
    root.mainloop()


if __name__ == "__main__":
    main()
