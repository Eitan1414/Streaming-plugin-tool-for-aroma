from __future__ import annotations

import json
import os
from pathlib import Path


def settings_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home()))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "WiiUStream"


def load_ip() -> str:
    path = settings_dir() / "settings.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, TypeError):
        return ""
    value = data.get("wii_u_ip", "")
    return value if isinstance(value, str) else ""


def save_ip(ip_address: str) -> None:
    directory = settings_dir()
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "settings.json"
    temporary = path.with_suffix(".tmp")
    temporary.write_text(
        json.dumps({"wii_u_ip": ip_address}, indent=2),
        encoding="utf-8",
    )
    temporary.replace(path)
