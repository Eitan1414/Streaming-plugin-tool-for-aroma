"""Wii U Stream desktop client."""

__version__ = "0.1.0"
