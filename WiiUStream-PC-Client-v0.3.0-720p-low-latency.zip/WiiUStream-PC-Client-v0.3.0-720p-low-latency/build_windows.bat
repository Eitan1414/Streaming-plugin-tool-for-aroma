@echo off
setlocal
py -m pip install --upgrade pip
py -m pip install -r requirements-build.txt
py -m unittest discover -s tests -v
py -m PyInstaller --noconfirm --clean --onefile --windowed --name WiiUStream-PC --icon assets\wiiustream.ico --hidden-import PIL._tkinter_finder main.py
if errorlevel 1 exit /b 1
echo.
echo Fichier cree : dist\WiiUStream-PC.exe
endlocal
