# Protocole WiiUStream v1

Le client accepte les paquets vidéo de 32 octets d'en-tête et jusqu'à 1472 octets par datagramme. Le plugin v0.3 utilise 1400 octets de charge utile par fragment.

Le client ne conserve que le `frameId` le plus récent par source et vérifie la taille complète ainsi que le CRC32 avant le décodage JPEG.
