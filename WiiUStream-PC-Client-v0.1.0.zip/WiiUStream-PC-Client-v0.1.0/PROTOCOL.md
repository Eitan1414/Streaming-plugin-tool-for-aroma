# Protocole WiiUStream v1

## Contrôle

Le client envoie chaque seconde un paquet de 12 octets au port UDP 9444 de la Wii U :

- magic `WUSC` (`0x57555343`)
- version `1`
- type `1` (HELLO)
- port vidéo client, normalement `9445`
- flags réservés à zéro

Tous les entiers sont en ordre réseau, donc big endian.

## Vidéo

Le client écoute le port UDP 9445. Chaque fragment JPEG commence par un en-tête de 32 octets comportant notamment l'identifiant de trame, le CRC32, le numéro du fragment, le nombre total de fragments, la résolution et la qualité JPEG.

Les trames incomplètes sont abandonnées après environ une seconde afin de privilégier une faible latence.
