from __future__ import annotations

import time
import zlib
from dataclasses import dataclass, field

from .protocol import FRAME_TIMEOUT_SECONDS, VideoHeader


@dataclass(frozen=True, slots=True)
class CompletedFrame:
    jpeg: bytes
    stream: int
    frame_id: int
    width: int
    height: int
    jpeg_quality: int


@dataclass(slots=True)
class _PendingFrame:
    header: VideoHeader
    created_at: float = field(default_factory=time.monotonic)
    chunks: list[bytes | None] = field(init=False)
    received_chunks: int = 0
    received_bytes: int = 0

    def __post_init__(self) -> None:
        self.chunks = [None] * self.header.chunk_count

    def matches(self, other: VideoHeader) -> bool:
        original = self.header
        return (
            original.frame_size == other.frame_size
            and original.frame_crc32 == other.frame_crc32
            and original.chunk_count == other.chunk_count
            and original.stream == other.stream
            and original.width == other.width
            and original.height == other.height
            and original.jpeg_quality == other.jpeg_quality
        )


class FrameAssembler:
    def __init__(self) -> None:
        self._pending: dict[tuple[int, int], _PendingFrame] = {}
        self.timed_out_frames = 0
        self.invalid_frames = 0

    def accept(self, header: VideoHeader, payload: bytes) -> CompletedFrame | None:
        self.cleanup_expired()
        key = (header.stream, header.frame_id)
        frame = self._pending.get(key)

        if frame is None:
            frame = _PendingFrame(header)
            self._pending[key] = frame
        elif not frame.matches(header):
            del self._pending[key]
            self.invalid_frames += 1
            return None

        if frame.chunks[header.chunk_index] is None:
            frame.chunks[header.chunk_index] = payload
            frame.received_chunks += 1
            frame.received_bytes += len(payload)

        if frame.received_chunks != frame.header.chunk_count:
            return None

        del self._pending[key]
        if frame.received_bytes != frame.header.frame_size:
            self.invalid_frames += 1
            return None

        if any(chunk is None for chunk in frame.chunks):
            self.invalid_frames += 1
            return None

        jpeg = b"".join(chunk for chunk in frame.chunks if chunk is not None)
        if len(jpeg) != frame.header.frame_size:
            self.invalid_frames += 1
            return None

        if (zlib.crc32(jpeg) & 0xFFFFFFFF) != frame.header.frame_crc32:
            self.invalid_frames += 1
            return None

        return CompletedFrame(
            jpeg=jpeg,
            stream=frame.header.stream,
            frame_id=frame.header.frame_id,
            width=frame.header.width,
            height=frame.header.height,
            jpeg_quality=frame.header.jpeg_quality,
        )

    def cleanup_expired(self, now: float | None = None) -> None:
        current = time.monotonic() if now is None else now
        expired = [
            key
            for key, frame in self._pending.items()
            if current - frame.created_at > FRAME_TIMEOUT_SECONDS
        ]
        for key in expired:
            del self._pending[key]
            self.timed_out_frames += 1
