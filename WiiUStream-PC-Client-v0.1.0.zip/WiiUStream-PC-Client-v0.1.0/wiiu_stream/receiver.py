from __future__ import annotations

import io
import queue
import socket
import threading
import time
from dataclasses import dataclass
from typing import Callable

from PIL import Image, UnidentifiedImageError

from .assembler import FrameAssembler
from .protocol import (
    CONTROL_PORT,
    DEFAULT_VIDEO_PORT,
    MAX_DATAGRAM_SIZE,
    hello_packet,
    parse_video_packet,
    validate_ipv4,
)


@dataclass(slots=True)
class DecodedFrame:
    image: Image.Image
    stream: int
    frame_id: int
    width: int
    height: int
    jpeg_quality: int
    jpeg_bytes: int


@dataclass(frozen=True, slots=True)
class StreamStats:
    fps: float
    megabits_per_second: float
    dropped_frames: int
    milliseconds_since_last_frame: int | None


StateCallback = Callable[[str, bool], None]


class StreamReceiver:
    def __init__(
        self,
        frame_queue: queue.Queue[DecodedFrame],
        state_callback: StateCallback,
        video_port: int = DEFAULT_VIDEO_PORT,
    ) -> None:
        self._frame_queue = frame_queue
        self._state_callback = state_callback
        self._video_port = video_port
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._socket: socket.socket | None = None
        self._stats_lock = threading.Lock()
        self._stats = StreamStats(0.0, 0.0, 0, None)

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self, ip_address: str) -> None:
        if self.running:
            return
        ip = validate_ipv4(ip_address)
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            args=(ip,),
            name="WiiUStreamReceiver",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        sock = self._socket
        self._socket = None
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=1.0)
        self._thread = None

    def stats(self) -> StreamStats:
        with self._stats_lock:
            return self._stats

    def _run(self, ip_address: str) -> None:
        assembler = FrameAssembler()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._socket = sock
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 * 1024 * 1024)
            sock.settimeout(0.25)
            sock.bind(("0.0.0.0", self._video_port))
        except OSError as exc:
            self._state_callback(f"Impossible d'ouvrir le port UDP {self._video_port} : {exc}", True)
            try:
                sock.close()
            except OSError:
                pass
            return

        self._state_callback(f"Connecté à {ip_address} — attente du flux…", False)
        target = (ip_address, CONTROL_PORT)
        hello = hello_packet(self._video_port)
        next_heartbeat = 0.0
        window_start = time.monotonic()
        window_frames = 0
        window_bytes = 0
        last_frame_at: float | None = None
        previous_frame_id: dict[int, int] = {}
        sequence_drops = 0

        try:
            while not self._stop_event.is_set():
                now = time.monotonic()
                if now >= next_heartbeat:
                    try:
                        sock.sendto(hello, target)
                    except OSError as exc:
                        if not self._stop_event.is_set():
                            self._state_callback(f"Erreur d'envoi vers la Wii U : {exc}", True)
                        break
                    next_heartbeat = now + 1.0

                try:
                    datagram, source = sock.recvfrom(MAX_DATAGRAM_SIZE)
                except socket.timeout:
                    assembler.cleanup_expired()
                    self._update_stats(
                        window_start,
                        window_frames,
                        window_bytes,
                        sequence_drops + assembler.timed_out_frames + assembler.invalid_frames,
                        last_frame_at,
                    )
                    continue
                except OSError as exc:
                    if not self._stop_event.is_set():
                        self._state_callback(f"Erreur réseau : {exc}", True)
                    break

                # Ignore unexpected senders once connected to a specific Wii U.
                if source[0] != ip_address:
                    continue

                parsed = parse_video_packet(datagram)
                if parsed is None:
                    continue
                header, payload = parsed
                completed = assembler.accept(header, payload)
                if completed is None:
                    continue

                try:
                    with Image.open(io.BytesIO(completed.jpeg)) as source_image:
                        image = source_image.convert("RGB")
                except (UnidentifiedImageError, OSError):
                    assembler.invalid_frames += 1
                    continue

                old_frame_id = previous_frame_id.get(completed.stream)
                if old_frame_id is not None:
                    gap = (completed.frame_id - old_frame_id) & 0xFFFFFFFF
                    if 1 < gap < 0x80000000:
                        sequence_drops += gap - 1
                previous_frame_id[completed.stream] = completed.frame_id

                last_frame_at = time.monotonic()
                window_frames += 1
                window_bytes += len(completed.jpeg)
                self._publish_latest(
                    DecodedFrame(
                        image=image,
                        stream=completed.stream,
                        frame_id=completed.frame_id,
                        width=completed.width,
                        height=completed.height,
                        jpeg_quality=completed.jpeg_quality,
                        jpeg_bytes=len(completed.jpeg),
                    )
                )

                elapsed = last_frame_at - window_start
                if elapsed >= 1.0:
                    self._set_stats(
                        fps=window_frames / elapsed,
                        megabits_per_second=(window_bytes * 8.0 / 1_000_000.0) / elapsed,
                        dropped_frames=(
                            sequence_drops + assembler.timed_out_frames + assembler.invalid_frames
                        ),
                        last_frame_at=last_frame_at,
                    )
                    window_start = last_frame_at
                    window_frames = 0
                    window_bytes = 0
        finally:
            try:
                sock.close()
            except OSError:
                pass
            if self._socket is sock:
                self._socket = None

    def _publish_latest(self, frame: DecodedFrame) -> None:
        while True:
            try:
                old = self._frame_queue.get_nowait()
                old.image.close()
            except queue.Empty:
                break
        try:
            self._frame_queue.put_nowait(frame)
        except queue.Full:
            frame.image.close()

    def _update_stats(
        self,
        window_start: float,
        window_frames: int,
        window_bytes: int,
        dropped_frames: int,
        last_frame_at: float | None,
    ) -> None:
        elapsed = time.monotonic() - window_start
        fps = window_frames / elapsed if elapsed > 0 else 0.0
        mbps = (window_bytes * 8.0 / 1_000_000.0) / elapsed if elapsed > 0 else 0.0
        self._set_stats(fps, mbps, dropped_frames, last_frame_at)

    def _set_stats(
        self,
        fps: float,
        megabits_per_second: float,
        dropped_frames: int,
        last_frame_at: float | None,
    ) -> None:
        if last_frame_at is None:
            since_ms = None
        else:
            since_ms = max(0, int((time.monotonic() - last_frame_at) * 1000))
        with self._stats_lock:
            self._stats = StreamStats(
                fps=fps,
                megabits_per_second=megabits_per_second,
                dropped_frames=dropped_frames,
                milliseconds_since_last_frame=since_ms,
            )
