from __future__ import annotations

import ipaddress
import struct
from dataclasses import dataclass

CONTROL_MAGIC = 0x57555343  # WUSC
VIDEO_MAGIC = 0x57555356  # WUSV
VERSION = 1
HELLO_TYPE = 1
CONTROL_PORT = 9444
DEFAULT_VIDEO_PORT = 9445
CONTROL_PACKET_SIZE = 12
VIDEO_HEADER_SIZE = 32
MAX_DATAGRAM_SIZE = 2048
MAX_FRAME_SIZE = 4 * 1024 * 1024
MAX_CHUNK_COUNT = 4096
FRAME_TIMEOUT_SECONDS = 1.0

_CONTROL_STRUCT = struct.Struct(">IBBHI")
_VIDEO_HEADER_STRUCT = struct.Struct(">IBBBBIIIHHHHHBB")


@dataclass(frozen=True, slots=True)
class VideoHeader:
    stream: int
    frame_id: int
    frame_size: int
    frame_crc32: int
    chunk_index: int
    chunk_count: int
    payload_size: int
    width: int
    height: int
    jpeg_quality: int


def hello_packet(video_port: int = DEFAULT_VIDEO_PORT) -> bytes:
    if not 1 <= video_port <= 65535:
        raise ValueError("Le port vidéo doit être compris entre 1 et 65535.")
    return _CONTROL_STRUCT.pack(
        CONTROL_MAGIC,
        VERSION,
        HELLO_TYPE,
        video_port,
        0,
    )


def parse_video_packet(datagram: bytes) -> tuple[VideoHeader, bytes] | None:
    packet_length = len(datagram)
    if packet_length < VIDEO_HEADER_SIZE:
        return None

    (
        magic,
        version,
        stream,
        flags,
        header_size,
        frame_id,
        frame_size,
        frame_crc32,
        chunk_index,
        chunk_count,
        payload_size,
        width,
        height,
        jpeg_quality,
        reserved,
    ) = _VIDEO_HEADER_STRUCT.unpack_from(datagram)

    if magic != VIDEO_MAGIC or version != VERSION or header_size != VIDEO_HEADER_SIZE:
        return None
    if stream not in (0, 1) or flags != 0 or reserved != 0:
        return None
    if not 1 <= frame_size <= MAX_FRAME_SIZE:
        return None
    if not 1 <= chunk_count <= MAX_CHUNK_COUNT or chunk_index >= chunk_count:
        return None
    if payload_size <= 0 or payload_size > packet_length - VIDEO_HEADER_SIZE:
        return None
    if width <= 0 or height <= 0 or not 1 <= jpeg_quality <= 100:
        return None

    payload_start = VIDEO_HEADER_SIZE
    payload_end = payload_start + payload_size
    header = VideoHeader(
        stream=stream,
        frame_id=frame_id,
        frame_size=frame_size,
        frame_crc32=frame_crc32,
        chunk_index=chunk_index,
        chunk_count=chunk_count,
        payload_size=payload_size,
        width=width,
        height=height,
        jpeg_quality=jpeg_quality,
    )
    return header, datagram[payload_start:payload_end]


def validate_ipv4(value: str) -> str:
    cleaned = value.strip()
    try:
        address = ipaddress.ip_address(cleaned)
    except ValueError as exc:
        raise ValueError("Adresse IPv4 invalide.") from exc
    if address.version != 4:
        raise ValueError("Une adresse IPv4 est nécessaire.")
    return str(address)
