# WiiUStream PC Client v0.1.0

Client de streaming PC compatible avec le plugin Aroma WiiUStream v0.2.2.

## Fonctions

- Réception UDP des images JPEG du GamePad ou de la TV.
- Reconstruction des fragments et vérification CRC32.
- Conservation de l'image la plus récente pour limiter la latence.
- Affichage redimensionné sans déformation.
- FPS, débit, pertes de trames et état du flux.
- Mémorisation de l'adresse IP de la Wii U.
- Plein écran avec `F11`, `Alt+Entrée` ou un double-clic.
- `Échap` pour quitter le plein écran.

## Utiliser l'exécutable Windows

1. Place la Wii U et le PC sur le même réseau local.
2. Active `WiiUStream.wps` dans Aroma.
3. Lance `WiiUStream-PC.exe`.
4. Autorise l'application dans le pare-feu Windows si une demande apparaît.
5. Entre l'adresse IPv4 de la Wii U et clique sur **Connexion**.

Le client envoie le signal de présence vers le port UDP `9444` et reçoit les images sur le port UDP `9445`.

## Lancer depuis le code source

Python 3.11 ou plus récent est recommandé.

```powershell
python -m pip install -r requirements.txt
python main.py
```

## Construire le `.exe` localement

Sous Windows :

```text
build_windows.bat
```

Le résultat sera placé dans `dist/WiiUStream-PC.exe`.

## Compilation GitHub Actions

Le workflow `.github/workflows/build-windows.yml` construit l'exécutable et publie l'artifact `WiiUStream-PC-Windows`.
