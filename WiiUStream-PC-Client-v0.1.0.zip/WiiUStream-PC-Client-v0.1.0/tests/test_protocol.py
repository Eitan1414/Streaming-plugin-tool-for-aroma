from __future__ import annotations

import random
import struct
import unittest
import zlib

from wiiu_stream.assembler import FrameAssembler
from wiiu_stream.protocol import (
    CONTROL_MAGIC,
    HELLO_TYPE,
    VERSION,
    VIDEO_HEADER_SIZE,
    VIDEO_MAGIC,
    hello_packet,
    parse_video_packet,
    validate_ipv4,
)


class ProtocolTests(unittest.TestCase):
    def test_hello_packet(self) -> None:
        packet = hello_packet(9445)
        self.assertEqual(len(packet), 12)
        self.assertEqual(struct.unpack(">IBBHI", packet), (CONTROL_MAGIC, VERSION, HELLO_TYPE, 9445, 0))

    def test_ipv4_validation(self) -> None:
        self.assertEqual(validate_ipv4(" 192.168.1.15 "), "192.168.1.15")
        with self.assertRaises(ValueError):
            validate_ipv4("999.1.1.1")

    def test_out_of_order_frame_reassembly(self) -> None:
        jpeg = b"\xff\xd8" + bytes(range(256)) * 17 + b"\xff\xd9"
        crc = zlib.crc32(jpeg) & 0xFFFFFFFF
        payload_size = 1200
        chunks = [jpeg[index:index + payload_size] for index in range(0, len(jpeg), payload_size)]
        datagrams: list[bytes] = []
        for index, payload in enumerate(chunks):
            header = struct.pack(
                ">IBBBBIIIHHHHHBB",
                VIDEO_MAGIC,
                VERSION,
                0,
                0,
                VIDEO_HEADER_SIZE,
                42,
                len(jpeg),
                crc,
                index,
                len(chunks),
                len(payload),
                854,
                480,
                60,
                0,
            )
            datagrams.append(header + payload)

        random.Random(1234).shuffle(datagrams)
        assembler = FrameAssembler()
        completed = None
        for datagram in datagrams:
            parsed = parse_video_packet(datagram)
            self.assertIsNotNone(parsed)
            assert parsed is not None
            completed = assembler.accept(*parsed) or completed

        self.assertIsNotNone(completed)
        assert completed is not None
        self.assertEqual(completed.jpeg, jpeg)
        self.assertEqual(completed.width, 854)
        self.assertEqual(completed.height, 480)

    def test_bad_crc_is_rejected(self) -> None:
        payload = b"not-a-real-jpeg"
        datagram = struct.pack(
            ">IBBBBIIIHHHHHBB",
            VIDEO_MAGIC,
            VERSION,
            1,
            0,
            VIDEO_HEADER_SIZE,
            9,
            len(payload),
            123,
            0,
            1,
            len(payload),
            640,
            360,
            50,
            0,
        ) + payload
        parsed = parse_video_packet(datagram)
        self.assertIsNotNone(parsed)
        assert parsed is not None
        assembler = FrameAssembler()
        self.assertIsNone(assembler.accept(*parsed))
        self.assertEqual(assembler.invalid_frames, 1)


if __name__ == "__main__":
    unittest.main()
