package com.wiiustream.client.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Process
import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketException
import java.net.SocketTimeoutException
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.CRC32

internal class StreamReceiver(
    private val listener: Listener,
    private val videoPort: Int = StreamProtocol.DEFAULT_VIDEO_PORT
) {
    interface Listener {
        fun onState(message: String, isError: Boolean = false)
        fun onFrame(frame: DecodedFrame)
        fun onStats(stats: StreamStats)
    }

    private val running = AtomicBoolean(false)
    private val closed = AtomicBoolean(false)
    private val sessionCounter = AtomicLong(0)
    private val socketRef = AtomicReference<DatagramSocket?>()
    private val latestEncoded = AtomicReference<EncodedFrame?>()
    private val decodeSignal = Semaphore(0)
    private val executor = Executors.newFixedThreadPool(3) { task ->
        Thread(task, "WiiUStream").apply { isDaemon = true }
    }

    private val latencySkips = AtomicLong(0)
    private val decodeErrors = AtomicLong(0)
    private val decodedSinceStats = AtomicLong(0)
    private val lastDecodedAt = AtomicLong(0)
    private val lastCompletedFrame = AtomicLong(-1)

    fun start(ipAddress: String) {
        if (closed.get() || !running.compareAndSet(false, true)) return
        val sessionId = sessionCounter.incrementAndGet()
        resetCounters()

        try {
            executor.execute {
                runNetworkSession(sessionId, ipAddress)
            }
        } catch (error: Throwable) {
            running.set(false)
            notifyState("Impossible de démarrer : ${error.safeMessage()}", true)
        }
    }

    private fun runNetworkSession(sessionId: Long, ipAddress: String) {
        setThreadPrioritySafely(Process.THREAD_PRIORITY_MORE_FAVORABLE)
        var socket: DatagramSocket? = null
        try {
            val address = StreamProtocol.resolveIpv4(ipAddress)
            socket = DatagramSocket(null).apply {
                reuseAddress = true
                soTimeout = 35
                bind(InetSocketAddress("0.0.0.0", videoPort))
                try {
                    receiveBufferSize = 128 * 1024
                } catch (_: Throwable) {
                    // Optional optimization; some Android network stacks reject it.
                }
            }
            socketRef.set(socket)
            notifyState("Connecté à ${address.hostAddress} — attente du flux…", false)

            executor.execute { guardedLoop("heartbeat") { heartbeatLoop(sessionId, socket, address) } }
            executor.execute { guardedLoop("decoder") { decodeLoop(sessionId) } }
            receiveLoop(sessionId, socket, address, FrameAssembler())
        } catch (error: Throwable) {
            if (isSessionActive(sessionId)) {
                notifyState("Erreur réseau : ${error.safeMessage()}", true)
            }
        } finally {
            try { socket?.close() } catch (_: Throwable) {}
            socketRef.compareAndSet(socket, null)
            latestEncoded.set(null)
            decodeSignal.release()
            if (sessionCounter.get() == sessionId) running.set(false)
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        sessionCounter.incrementAndGet()
        try { socketRef.getAndSet(null)?.close() } catch (_: Throwable) {}
        latestEncoded.set(null)
        decodeSignal.release()
        notifyState("Déconnecté", false)
    }

    fun close() {
        if (!closed.compareAndSet(false, true)) return
        stop()
        executor.shutdownNow()
        try {
            executor.awaitTermination(300, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    private fun guardedLoop(name: String, block: () -> Unit) {
        try {
            block()
        } catch (error: Throwable) {
            if (!closed.get()) notifyState("Erreur $name : ${error.safeMessage()}", true)
        }
    }

    private fun resetCounters() {
        latestEncoded.set(null)
        decodeSignal.drainPermits()
        latencySkips.set(0)
        decodeErrors.set(0)
        decodedSinceStats.set(0)
        lastDecodedAt.set(0)
        lastCompletedFrame.set(-1)
    }

    private fun isSessionActive(sessionId: Long): Boolean =
        running.get() && !closed.get() && sessionCounter.get() == sessionId

    private fun heartbeatLoop(sessionId: Long, socket: DatagramSocket, address: InetAddress) {
        setThreadPrioritySafely(Process.THREAD_PRIORITY_BACKGROUND)
        val payload = StreamProtocol.helloPacket(videoPort)
        val packet = DatagramPacket(payload, payload.size, address, StreamProtocol.CONTROL_PORT)

        while (isSessionActive(sessionId) && !socket.isClosed) {
            try {
                socket.send(packet)
            } catch (error: SocketException) {
                if (isSessionActive(sessionId)) notifyState("Connexion interrompue", true)
                break
            } catch (error: Throwable) {
                if (isSessionActive(sessionId)) {
                    notifyState("Signal de connexion impossible : ${error.safeMessage()}", true)
                }
            }

            try {
                Thread.sleep(1_000)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                break
            }
        }
    }

    private fun receiveLoop(
        sessionId: Long,
        socket: DatagramSocket,
        expectedAddress: InetAddress,
        assembler: FrameAssembler
    ) {
        val buffer = ByteArray(StreamProtocol.MAX_DATAGRAM_SIZE)
        val packet = DatagramPacket(buffer, buffer.size)
        var receivedBytes = 0L
        var windowCompleted = 0L
        var windowBytes = 0L
        var windowStart = SystemClock.elapsedRealtime()
        var sequenceDrops = 0L

        while (isSessionActive(sessionId) && !socket.isClosed) {
            packet.length = buffer.size
            try {
                socket.receive(packet)
            } catch (_: SocketTimeoutException) {
                assembler.cleanupExpired()
                val now = SystemClock.elapsedRealtime()
                if (now - windowStart >= 1_000) {
                    publishStats(now, windowStart, windowCompleted, windowBytes, assembler, sequenceDrops, receivedBytes)
                    windowStart = now
                    windowCompleted = 0
                    windowBytes = 0
                }
                continue
            } catch (error: SocketException) {
                if (isSessionActive(sessionId)) notifyState("Socket fermée : ${error.safeMessage()}", true)
                break
            } catch (error: Throwable) {
                if (isSessionActive(sessionId)) notifyState("Réception impossible : ${error.safeMessage()}", true)
                break
            }

            if (packet.address != expectedAddress) continue
            val packetLength = packet.length
            receivedBytes += packetLength

            val header = StreamProtocol.parseVideoHeader(buffer, packetLength) ?: continue
            val completed = try {
                assembler.accept(header, buffer)
            } catch (error: OutOfMemoryError) {
                decodeErrors.incrementAndGet()
                notifyState("Mémoire insuffisante pour une image 480p", true)
                null
            } ?: continue

            val previous = lastCompletedFrame.getAndSet(completed.frameId)
            if (previous >= 0) {
                val gap = (completed.frameId - previous) and 0xFFFF_FFFFL
                if (gap in 2L..0x7FFF_FFFFL) sequenceDrops += gap - 1
            }

            windowCompleted++
            windowBytes += completed.jpeg.size
            publishLatestEncoded(completed)

            val now = SystemClock.elapsedRealtime()
            if (now - windowStart >= 1_000) {
                publishStats(now, windowStart, windowCompleted, windowBytes, assembler, sequenceDrops, receivedBytes)
                windowStart = now
                windowCompleted = 0
                windowBytes = 0
            }
        }
    }

    private fun publishLatestEncoded(frame: EncodedFrame) {
        if (latestEncoded.getAndSet(frame) != null) latencySkips.incrementAndGet()
        if (decodeSignal.availablePermits() == 0) decodeSignal.release()
    }

    private fun decodeLoop(sessionId: Long) {
        setThreadPrioritySafely(Process.THREAD_PRIORITY_DISPLAY)
        val options = BitmapFactory.Options().apply {
            inScaled = false
            inDither = false
            // RGB_565 halves bitmap memory and decodes quickly at 854x480.
            inPreferredConfig = Bitmap.Config.RGB_565
        }

        while (isSessionActive(sessionId)) {
            try {
                if (!decodeSignal.tryAcquire(100, TimeUnit.MILLISECONDS)) continue
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                break
            }
            decodeSignal.drainPermits()

            var encoded = latestEncoded.getAndSet(null) ?: continue
            while (true) {
                val newer = latestEncoded.getAndSet(null) ?: break
                encoded = newer
                latencySkips.incrementAndGet()
            }

            try {
                val crc = CRC32().apply { update(encoded.jpeg) }.value
                if (crc != encoded.expectedCrc32) {
                    decodeErrors.incrementAndGet()
                    continue
                }

                val bitmap = BitmapFactory.decodeByteArray(encoded.jpeg, 0, encoded.jpeg.size, options)
                if (bitmap == null) {
                    decodeErrors.incrementAndGet()
                    continue
                }

                if (latestEncoded.get() != null) {
                    bitmap.recycle()
                    latencySkips.incrementAndGet()
                    continue
                }

                decodedSinceStats.incrementAndGet()
                lastDecodedAt.set(SystemClock.elapsedRealtime())
                try {
                    listener.onFrame(
                        DecodedFrame(bitmap, encoded.stream, encoded.frameId, encoded.width,
                            encoded.height, encoded.jpegQuality, encoded.jpeg.size)
                    )
                } catch (error: Throwable) {
                    if (!bitmap.isRecycled) bitmap.recycle()
                    throw error
                }
            } catch (error: OutOfMemoryError) {
                decodeErrors.incrementAndGet()
                latestEncoded.set(null)
                notifyState("Mémoire vidéo insuffisante : baisse la qualité JPEG", true)
                try { Thread.sleep(250) } catch (_: InterruptedException) { break }
            } catch (error: Throwable) {
                decodeErrors.incrementAndGet()
                notifyState("Décodage impossible : ${error.safeMessage()}", true)
            }
        }
    }

    private fun publishStats(
        now: Long,
        windowStart: Long,
        completedFrames: Long,
        bytes: Long,
        assembler: FrameAssembler,
        sequenceDrops: Long,
        totalBytes: Long
    ) {
        val elapsed = (now - windowStart).coerceAtLeast(1L) / 1_000.0
        val decoded = decodedSinceStats.getAndSet(0)
        val lastFrame = lastDecodedAt.get()
        try {
            listener.onStats(
                StreamStats(
                    receiveFps = completedFrames / elapsed,
                    displayFps = decoded / elapsed,
                    megabitsPerSecond = (bytes * 8.0 / 1_000_000.0) / elapsed,
                    droppedFrames = sequenceDrops + assembler.timedOutFrames + assembler.invalidFrames +
                        assembler.staleFrames + decodeErrors.get(),
                    skippedForLatency = latencySkips.get(),
                    totalMegabytes = totalBytes / (1024.0 * 1024.0),
                    millisecondsSinceLastFrame = if (lastFrame == 0L) Long.MAX_VALUE else now - lastFrame
                )
            )
        } catch (_: Throwable) {
            // UI may be closing; never terminate a network thread for statistics.
        }
    }

    private fun notifyState(message: String, isError: Boolean) {
        try { listener.onState(message, isError) } catch (_: Throwable) {}
    }

    private fun setThreadPrioritySafely(priority: Int) {
        try { Process.setThreadPriority(priority) } catch (_: Throwable) {}
    }

    private fun Throwable.safeMessage(): String = message ?: javaClass.simpleName
}

data class DecodedFrame(
    val bitmap: Bitmap,
    val stream: Int,
    val frameId: Long,
    val width: Int,
    val height: Int,
    val jpegQuality: Int,
    val jpegBytes: Int
)

data class StreamStats(
    val receiveFps: Double,
    val displayFps: Double,
    val megabitsPerSecond: Double,
    val droppedFrames: Long,
    val skippedForLatency: Long,
    val totalMegabytes: Double,
    val millisecondsSinceLastFrame: Long
)
