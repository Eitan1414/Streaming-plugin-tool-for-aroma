package com.wiiustream.client.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * Conservative renderer for devices whose SurfaceView hardware canvas is
 * unstable. The decoder only publishes the newest bitmap. Actual drawing is
 * performed by Android's UI thread through View.onDraw().
 */
internal class StreamView(context: Context) : View(context) {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val frameLock = Any()

    private var pendingBitmap: Bitmap? = null
    private var displayedBitmap: Bitmap? = null

    init {
        setBackgroundColor(Color.BLACK)
    }

    fun renderFrame(bitmap: Bitmap): Boolean {
        if (bitmap.isRecycled) return false

        synchronized(frameLock) {
            pendingBitmap?.let { old ->
                if (old !== bitmap && !old.isRecycled) old.recycle()
            }
            pendingBitmap = bitmap
        }

        postInvalidate()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        var previous: Bitmap? = null
        val frame: Bitmap? = synchronized(frameLock) {
            pendingBitmap?.let { newest ->
                previous = displayedBitmap
                displayedBitmap = newest
                pendingBitmap = null
            }
            displayedBitmap
        }

        if (frame != null && !frame.isRecycled && width > 0 && height > 0) {
            canvas.drawBitmap(frame, null, destination(frame, width, height), paint)
        }

        previous?.let { old ->
            if (old !== frame && !old.isRecycled) old.recycle()
        }
    }

    fun clearFrame() {
        val frames = synchronized(frameLock) {
            val values = listOfNotNull(pendingBitmap, displayedBitmap).distinctBy { System.identityHashCode(it) }
            pendingBitmap = null
            displayedBitmap = null
            values
        }
        frames.forEach { bitmap ->
            if (!bitmap.isRecycled) bitmap.recycle()
        }
        postInvalidate()
    }

    override fun onDetachedFromWindow() {
        clearFrame()
        super.onDetachedFromWindow()
    }

    private fun destination(bitmap: Bitmap, viewWidth: Int, viewHeight: Int): RectF {
        if (viewWidth <= 0 || viewHeight <= 0 || bitmap.height <= 0) return RectF()
        val sourceRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        val viewRatio = viewWidth.toFloat() / viewHeight.toFloat()
        return if (sourceRatio > viewRatio) {
            val scaledHeight = viewWidth / sourceRatio
            val top = (viewHeight - scaledHeight) / 2f
            RectF(0f, top, viewWidth.toFloat(), top + scaledHeight)
        } else {
            val scaledWidth = viewHeight * sourceRatio
            val left = (viewWidth - scaledWidth) / 2f
            RectF(left, 0f, left + scaledWidth, viewHeight.toFloat())
        }
    }
}
