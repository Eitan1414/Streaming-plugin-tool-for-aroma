# Tests conseillés

1. Désinstaller l’ancienne application avant d’installer cet APK debug.
2. Lancer le plugin avec 854×480, qualité 42, 15 FPS et qualité adaptative activée.
3. Vérifier que l’application affiche 10–15 FPS sans retard croissant.
4. Si le nombre de pertes monte rapidement, tester 12 FPS puis une qualité de 38.
5. Si l’application se ferme encore, récupérer le bloc `FATAL EXCEPTION` avec `adb logcat`.
