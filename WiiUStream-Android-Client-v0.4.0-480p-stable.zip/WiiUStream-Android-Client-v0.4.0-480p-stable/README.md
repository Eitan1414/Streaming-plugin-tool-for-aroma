# Wii U Stream Android 480p Stable v0.4.0

Client Android conçu pour le plugin **Wii U Stream 480p Performance v0.4.0**.

Objectif : afficher naturellement un flux **854×480 à 10–15 FPS**, sans accumuler plusieurs secondes de retard.

## Optimisations

- aucun code 720p ;
- réception UDP et décodage JPEG séparés ;
- un seul JPEG en attente ;
- suppression immédiate des images anciennes ;
- tampon UDP limité à 128 Kio ;
- délai maximal d’assemblage de 180 ms ;
- décodage `RGB_565` ;
- rendu Android classique et stable, sans `SurfaceView` matériel ni `WifiLock` ;
- validation stricte du format 854×480 ;
- conservation des proportions et plein écran.

## Connexion

- Wii U et téléphone sur le même réseau local ;
- saisir l’adresse IPv4 de la Wii U ;
- port de contrôle UDP : 9444 ;
- port vidéo UDP : 9445.

## Réglages recommandés du plugin

- Adaptive quality : On
- JPEG quality ceiling : 42
- Target FPS : 15

Pour un jeu lourd : qualité 36–40 et 10–12 FPS.
